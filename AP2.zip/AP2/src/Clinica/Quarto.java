package Clinica;

public class Quarto {
	public int numero;
	public int andar;
	
	
	public Quarto(int numero, int andar, Paciente paciente) {
		this.numero = numero;
		this.andar = andar;
	}
	
	@Override
	public String toString() {
		return "Quarto\n" + "Andar: " + this.andar + "\nNumero: " + this.numero;
	}
	
}

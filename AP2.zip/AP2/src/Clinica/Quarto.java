package Clinica;

public class Quarto {
	public int numero;
	public int andar;
	public Paciente paciente;
	
	
	public Quarto(int numero, int andar, Paciente paciente) {
		this.numero = numero;
		this.andar = andar;
		this.paciente = paciente;
	}
	
	
	
	public void cadastro_quarto() {
		
	}
}

package Clinica;
import java.util.*;
public class Medico extends Pessoa{
	
	public int crm;
	private int salario;
	public ArrayList<String> especialidades = new ArrayList<String>();
	public String funcao;
	
	public Medico(String nome, int cpf, int telefone, int crm, int salario, ArrayList<String> especialidades, String funcao) {
		super(nome, cpf, telefone);
		this.crm = crm;
		this.salario = salario;
		this.especialidades = especialidades;
		this.funcao = funcao;
	}

	public String getNome() {
		return this.nome;
	}
	
	 public void addEspecialidade(String especialidade) {
		 this.especialidades.add(especialidade);
	 }
	 
	 public int getCPF() {
	        return this.cpf;
	 }       
	 
	 public int getSalario() {
		 return this.salario;
	 }
	 
	 
	 @Override
	 public String toString() {
		 return "Nome: " + this.nome + "\nCRM: " + this.crm + "\nCPF: " + this.cpf + "\nSalario: " + this.salario + "\nFunção: " + this.funcao + "\nTelefone: " + this.telefone;
	 }
}


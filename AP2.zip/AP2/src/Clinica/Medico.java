package Clinica;
import java.util.*;
public class Medico {
	
	public int crm;
	private int cpf;
	public String nome;
	public int telefone;
	private int salario;
	public ArrayList<String> especialidades = new ArrayList<String>();
	public String funcao;
	
	
	public Medico(int crm, int cpf, String nome, int telefone, int salario, String funcao) {
		this.crm = crm;
		this.cpf = cpf;
		this.nome = nome;
		this.telefone = telefone;
		this.salario = salario;
		this.funcao = funcao;
	}
	
	 public void addEspecialidade(String especialidade) {
		 this.especialidades.add(especialidade);
	 }
	 
	 public int getCPF() {
	        return this.cpf;
	 }       
	 
	 public int getSalario() {
		 return this.salario;
	 }
	 
	 public String toString() {
		 return "Nome: " + this.nome + "\nCRM: " + this.crm + "\nCPF: " + this.cpf + "\nSalario: " + this.salario + "\nFunção: " + this.funcao + "\nTelefone: " + this.telefone;
	 }
}


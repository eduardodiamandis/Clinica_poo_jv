package Clinica;
import java.util.*;
public class Medico {
	
	public String crm;
	private String cpf;
	public String nome;
	public String telefone;
	private int salario;
	public ArrayList <String> especialidades;
	public String funcao;
	
	
	public Medico(String crm, String cpf, String nome, String telefone, int salario, ArrayList<String> especialidades, String funcao) {
		this.crm = crm;
		this.cpf = cpf;
		this.nome = nome;
		this.telefone = telefone;
		this.salario = salario;
		this.especialidades = especialidades;
		this.funcao = funcao;
	}
	
	
	
	
		
}


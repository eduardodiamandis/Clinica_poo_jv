package Clinica;

public class Pessoa {
	public String nome;
	public int cpf;
	public int telefone;
	
	
	public Pessoa(String nome, int cpf, int telefone) {
		this.nome = nome;
		this.cpf = cpf;
		this.telefone = telefone;
	}
	
}

package Clinica;

import java.util.Date;

public class HistoricoMedico {
    private Date data;
    private Observacao relatorio;
    private Medico nome;
    

    public HistoricoMedico(Date data, Observacao relatorio, Medico nome) {
        this.data = data;
        this.relatorio = relatorio;
        this.nome = nome;
    }

    public Date getData() {
        return this.data;
    }

    public Observacao getObservacao() {
        return this.relatorio;
    }

    public Medico getNomeMedico() {
        return this.nome;
    }
}
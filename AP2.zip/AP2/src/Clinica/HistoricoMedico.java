package Clinica;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class HistoricoMedico extends Observacao {
    private LocalDate data;
    private Medico medico;
    private LocalTime horario;

    private static final DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm");
    private static final DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    public HistoricoMedico(String texto, LocalDate data, Observacao observacao, Medico medico, LocalTime horario) {
        super(texto);
        this.data = data;
        this.medico = medico;
        this.horario = horario;
    }

    public LocalDate getData() {
        return this.data;
    }

    public Medico getMedico() {
        return this.medico;
    }

    public LocalTime getHorario() {
        return this.horario;
    }

    public void setHorario(LocalTime horario) {
        this.horario = horario;
    }

    public void setHorario(String horario) {
        this.horario = LocalTime.parse(horario, timeFormatter);
    }

    public String getHorarioFormatado() {
        return this.horario.format(timeFormatter);
    }

    @Override
    public String toString() {
        return
               "Data: " + this.getData().format(dateFormatter) + "\n" +
               "Horário: " + this.getHorarioFormatado() + "\n" +
               "Médico: " + this.getMedico().getNome() + "\n" +
               "Observação: " + this.getTexto();
    }
}
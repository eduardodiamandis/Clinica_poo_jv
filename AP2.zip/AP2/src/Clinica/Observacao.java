package Clinica;

public class Observacao {
    private String texto;

    public Observacao(String texto) {
        this.texto = texto;
    }

    public String getTexto() {
        return this.texto;
    }

    @Override
    public String toString() {
        return this.texto;
    }
}

package Clinica;

import java.util.Date;

public class Observacao extends HistoricoMedico{
	
	public String observacao;

	public Observacao(Date data, Observacao relatorio, Medico nome, String observacao) {
		super(data, relatorio, nome);
		this.observacao = observacao;
		
	}
	
}


package Clinica;

import java.util.*;
public class Paciente {
	
	public String nome;
	public int cpf;
	public int rg;
	public String endereco;
	public int telefone;
	public Date data_nascimento;
	public Medico medico;
	public HistoricoMedico historico;
	
	
	public Paciente(String nome, int cpf, int rg, String endereco, int telefone, Date data_nascimento, Medico medico, HistoricoMedico historico) {
		this.cpf = cpf;
		this.rg = rg;
		this.endereco = endereco;
		this.telefone = telefone;
		this.data_nascimento = data_nascimento;
		this.medico = medico;
		this.historico = historico;
	}
	
	
}

package Clinica;
import java.util.*;
public class Paciente {
	public String nome;
	public String cpf;
	public String rg;
	public String endereco;
	public String telefone;
	public String data_nascimento;
	public Medico medico;
	public ArrayList <Paciente> pacientes = new ArrayList<Paciente>();
	
	
	public Paciente(String nome, String cpf, String rg, String endereco, String telefone, String data_nascimento, Medico medico, Paciente paciente) {
		this.cpf = cpf;
		this.rg = rg;
		this.endereco = endereco;
		this.telefone = telefone;
		this.data_nascimento = data_nascimento;
		this.medico = medico;
		this.pacientes.add(paciente);
	}
	
	
	@Override
	public boolean equals (Object obj) {
		Paciente p = (Paciente)obj;
		
		if (this.cpf == p.cpf) {
			
		}
	}
	
}
	


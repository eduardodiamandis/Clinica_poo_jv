package Clinica;

import java.time.LocalDate;
public class Paciente extends Pessoa{ 
	

	public int rg;
	public String endereco;
	public LocalDate data_nascimento;
	public Medico medico;
	public HistoricoMedico historico;
	public Quarto quarto;
	
	
	public Paciente(Quarto quarto, String nome, int cpf, int telefone, int rg, String endereco, LocalDate data_nascimento, Medico medico, HistoricoMedico historico) {
		super(nome, cpf, telefone);
		this.rg = rg;
		this.endereco = endereco;
		this.data_nascimento = data_nascimento;
		this.medico = medico;
		this.historico = historico;
		this.quarto = quarto;
	}
	
	
	@Override
	public String toString() {
		return "Nome: " + this.nome + "\nCPF: " + this.cpf + "\nRG: " + this.rg + "\nEndereço: " + this.endereco + "\nData Nascimento: " + this.data_nascimento + 
				"\nNome do médico responsavel: " + this.medico.nome + "\nTelefone: " + this.telefone + "\nHistórico" + this.historico + "\n" + this.quarto;
	}
	
}

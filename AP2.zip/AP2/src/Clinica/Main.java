package Clinica;

public class Main {

	public static void main(String[] args) {
		
		Medico m1 = new Medico (1235, 158947, "Pedro", 7894, 7000, "cardiologista");
		
		System.out.println(m1);

	}

}



// Breno Oliveira de Paulo - 2201453
// Eduardo Diamandis da Cruz - 2203426





package Clinica;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {
        // Criando médico
        ArrayList<String> especialidadesMedico = new ArrayList<>();
        especialidadesMedico.add("Ortopedia");
        especialidadesMedico.add("Traumatologia");

        Medico medico1 = new Medico("Dr. João Silva", 123456789, 987654321, 1234, 10000, especialidadesMedico, "Médico Clínico");

        // Adicionando uma nova especialidade ao médico
        medico1.addEspecialidade("Cardiologia");

        // Criando observação médica
        Observacao observacao = new Observacao("Paciente em recuperação.");

        // Criando histórico médico para o paciente
        LocalDate dataHistorico = LocalDate.now();
        LocalTime horarioHistorico = LocalTime.now();
        HistoricoMedico historicoMedico = new HistoricoMedico("Paciente em recuperação", dataHistorico, observacao, medico1, horarioHistorico);

        // Criando quarto
        Quarto quarto1 = new Quarto(101, 1, null); // Paciente será associado após a criação

        // Criando paciente e associando ao quarto
        LocalDate dataNascimento = LocalDate.of(1980, 5, 15);
        Paciente paciente1 = new Paciente(quarto1, "Maria Oliveira", 987654321, 123456789, 1234567, "Rua B, 456", dataNascimento, medico1, historicoMedico);


        // Exibindo informações
        System.out.println("Informações do Médico:");
        System.out.println(medico1);

        System.out.println("\nInformações do Paciente:");
        System.out.println(paciente1);

        System.out.println("\nInformações do Quarto:");
        System.out.println(quarto1);

        System.out.println("\nHistórico Médico:");
        System.out.println(historicoMedico);
    }
}
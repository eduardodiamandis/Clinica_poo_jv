package Clinica;

import java.util.*;

public class Main {

    public static void main(String[] args) {
        // Criando instâncias de Medico
        Medico medico1 = new Medico(12345, 111111111, "Dr. Carlos", 99887766, 10000, "Cardiologista");
        medico1.addEspecialidade("Cardiologia");
        medico1.addEspecialidade("Clínica Geral");

        Medico medico2 = new Medico(54321, 222222222, "Dra. Ana", 88776655, 12000, "Neurologista");
        medico2.addEspecialidade("Neurologia");

        // Criando instâncias de Observacao
        Observacao observacao1 = new Observacao(new Date(), null, medico1, "Paciente com dor no peito.");
        Observacao observacao2 = new Observacao(new Date(), null, medico2, "Paciente com dor de cabeça persistente.");

        // Criando instâncias de HistoricoMedico
        HistoricoMedico historico1 = new HistoricoMedico(new Date(), observacao1, medico1);
        HistoricoMedico historico2 = new HistoricoMedico(new Date(), observacao2, medico2);

        // Criando instâncias de Paciente
        Paciente paciente1 = new Paciente("João Silva", 333333333, 123456789, "Rua A, 123", 99887766, new Date(90, 0, 1), medico1, historico1);
        Paciente paciente2 = new Paciente("Maria Souza", 444444444, 987654321, "Rua B, 456", 88776655, new Date(92, 1, 2), medico2, historico2);

        // Criando instâncias de Quarto
        Quarto quarto1 = new Quarto(101, 1, paciente1);
        Quarto quarto2 = new Quarto(202, 2, paciente2);

        // Testando as funcionalidades das classes
        System.out.println("Detalhes do Médico 1:");
        System.out.println(medico1);

        System.out.println("\nDetalhes do Médico 2:");
        System.out.println(medico2);

        System.out.println("\nDetalhes do Paciente 1:");
        System.out.println("Nome: " + paciente1.nome);
        System.out.println("CPF: " + paciente1.cpf);
        System.out.println("RG: " + paciente1.rg);
        System.out.println("Endereço: " + paciente1.endereco);
        System.out.println("Telefone: " + paciente1.telefone);
        System.out.println("Data de Nascimento: " + paciente1.data_nascimento);
        System.out.println("Médico Responsável: " + paciente1.medico.nome);
        System.out.println("Histórico Médico: " + paciente1.historico.getObservacao().observacao);

        System.out.println("\nDetalhes do Paciente 2:");
        System.out.println("Nome: " + paciente2.nome);
        System.out.println("CPF: " + paciente2.cpf);
        System.out.println("RG: " + paciente2.rg);
        System.out.println("Endereço: " + paciente2.endereco);
        System.out.println("Telefone: " + paciente2.telefone);
        System.out.println("Data de Nascimento: " + paciente2.data_nascimento);
        System.out.println("Médico Responsável: " + paciente2.medico.nome);
        System.out.println("Histórico Médico: " + paciente2.historico.getObservacao().observacao);

        System.out.println("\nDetalhes do Quarto 1:");
        System.out.println("Número: " + quarto1.numero);
        System.out.println("Andar: " + quarto1.andar);
        System.out.println("Paciente: " + quarto1.paciente.nome);

        System.out.println("\nDetalhes do Quarto 2:");
        System.out.println("Número: " + quarto2.numero);
        System.out.println("Andar: " + quarto2.andar);
        System.out.println("Paciente: " + quarto2.paciente.nome);
    }
}

